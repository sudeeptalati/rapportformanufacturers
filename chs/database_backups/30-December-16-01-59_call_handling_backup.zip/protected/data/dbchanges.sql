DELETE FROM "gm_json_fields" WHERE "1"

INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('2','TEXT','customer|fullname','customer_fullname','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('3','TEXT','customer|postcode','customer_postcode','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('4','TEXT','product|brand|name','product_brand_name','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('5','INTEGER','product|model_number','product_model_number','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('6','TEXT','product|productType|name','product_product_type_name','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('7','TEXT','fault_description','fault_description','','','');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('8','TEXT','customer|telephone','customer_telephone','4','1','1457946525');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('9','TEXT','customer|mobile','customer_mobile','5','1','1457946547');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('10','TEXT','customer|address_line_1','customer_address_line_1','1','1','1481289615');
INSERT INTO "gm_json_fields" ("id","field_type","field_relation","field_label","sort_order","active","created") VALUES ('11','TEXT','customer|town','customer_town','1','1','1481289643');



ALTER TABLE 'job_status' ADD COLUMN 'keyword' TEXT;